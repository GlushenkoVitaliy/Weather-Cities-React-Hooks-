
export default class ServiseWeatherApi {

    async getResource(url) {
        
        const res = await fetch(url);

        if (!res.ok) {
            throw new Error(`Could not fetch ${url}` + 
                `, received ${res.status}`)
        }
        return await res.json();
    }

    getDataByCityName(city) {
        return this.getResource(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=6aebc52b238b091e301f34ff37af58c0`)
    }

    getDataByCordinates(lat, lon) {
        return this.getResource(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=6aebc52b238b091e301f34ff37af58c0`)
    }
}

