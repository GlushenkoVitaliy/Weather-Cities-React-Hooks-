import React, {Component} from 'react';

import ServiceWeatherApi from '../../serviseWeatherApi/ServiceWeatherApi';

import './WeatherToday.css';

export default class WeatherToday extends Component {

    serviceWeatherApi = new ServiceWeatherApi();

    state = {
        city: null,
        data: null,
        temperatureDay: null,
        wind: null
    };

    constructor() {
        super();
        this.getLocationCity();
    }

    getLocationCity() {

        let latitude = null;
        let longitude = null;

        function success(position) {
           
          latitude = position.coords.latitude;
          longitude = position.coords.longitude;
          
        };
        
        navigator.geolocation.getCurrentPosition(success);
        
        this.getDataWeather(latitude, longitude);
        
        
    
    }

    getDataWeather() {
        this.serviceWeatherApi.getDataByCordinates(latitude, longitude)
            .then((data) => {
                this.setState({
                    city: data.city.name,
                    data: data.dt,
                    temperatureDay: data.main.temp,
                    wind: data.wind.speed
                })
            });
    }

    render() {

        const { city, data, temperatureDay, wind } = this.state;

        return (
            <div className='weather-today'>
                <div className='city'>
                    <h2>{city}</h2>
                </div>
                <div className='date'>date {data}</div>
                <div className='temp'>temp {temperatureDay}</div>
                <div className='wind'>wind {wind}</div>
            </div>
        )
    }
}