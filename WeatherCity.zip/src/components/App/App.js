import React, {Component} from 'react';

import WeaterToday from '../WeatherToday/WeatherToday';

import './App.css';

export default class App extends Component {

    render() {
        return (
            <div className='weather-app'>
                <h1 className='header'>Weather City</h1>
                <div className='weather-window'>
                    <WeaterToday />
                </div>
                
            </div>
        )
    }
}