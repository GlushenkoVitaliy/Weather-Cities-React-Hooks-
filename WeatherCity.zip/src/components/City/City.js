import React, {Component} from 'react';

import './City.css';

export default class City extends Component {

    state = {
        city: null
    }

    render() {

        const { city } = this.state;

        return (
            <div className='city'>
                <h2>City</h2>
            </div>
        )
    }
}